#!/bin/sh
cd /usr/local/darjeeling
./darjeeling.elf -u 2=/dev/ttyACM0

