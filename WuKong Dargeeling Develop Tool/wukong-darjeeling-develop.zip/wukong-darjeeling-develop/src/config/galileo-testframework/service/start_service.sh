#!/bin/sh
cd /usr/local/darjeeling
./darjeeling.elf REPLACE_THIS_WITH_BOOT_PARAMETERS

