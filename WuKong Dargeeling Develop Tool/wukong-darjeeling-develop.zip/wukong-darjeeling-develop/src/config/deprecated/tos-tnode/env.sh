export NESC1=/usr/lib/ncc/nesc1
export NESC_LIB=/usr/lib/ncc