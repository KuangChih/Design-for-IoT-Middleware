/**
 * 
 */
package com.ihp;

/**
 * @author Michael Maaser
 *
 */
public interface BenchmarkImplementation {

	void runTest(int times);
	
	String getName();

}
